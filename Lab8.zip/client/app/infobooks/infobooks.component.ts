import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-infobooks',
  templateUrl: './infobooks.component.html',
  styleUrls: ['./infobooks.component.css']
})
export class InfobooksComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
