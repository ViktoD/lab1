﻿namespace lab3.Database
{
    public class DbConnection
    {
        public string ConnectionString { get; set; } = null!;
        public string Database { get; set; } = null!;
       
    }
}
